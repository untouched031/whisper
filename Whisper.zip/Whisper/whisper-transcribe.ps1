function whisper-transcribe {

    [CmdletBinding()]
    param(

        [Parameter(Mandatory, Position = 0)]
        [string]$MediaPath,

        [Parameter(Position = 1)]
        [string]$Output

    )

    # --------------------------------------------------------
    # Validate input
    # --------------------------------------------------------

    if (!(Test-Path -LiteralPath $MediaPath -PathType Leaf)) {
        throw "File not found:`n$MediaPath"
    }

    # --------------------------------------------------------
    # Dedicated Python environment
    # --------------------------------------------------------

    $Python = "C:\.venv\whisper-env\Scripts\python.exe"

    if (!(Test-Path -LiteralPath $Python -PathType Leaf)) {
        throw "Whisper Python environment missing:`n$Python"
    }

    # --------------------------------------------------------
    # Resolve paths
    # --------------------------------------------------------

    $MediaPath = (Resolve-Path -LiteralPath $MediaPath).Path

    $Name = [System.IO.Path]::GetFileNameWithoutExtension($MediaPath)
    $Dir  = Split-Path -LiteralPath $MediaPath -Parent

    if ([string]::IsNullOrWhiteSpace($Output)) {
        $Output = Join-Path $Dir ($Name + ".srt")
    }

    $Output = [System.IO.Path]::GetFullPath($Output)
    $OutputDir = Split-Path -LiteralPath $Output -Parent

    if (!(Test-Path -LiteralPath $OutputDir)) {
        New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
    }

    # --------------------------------------------------------
    # Display information
    # --------------------------------------------------------

    Write-Host ""
    Write-Host "======================================" -ForegroundColor Cyan
    Write-Host " Whisper large-v2 CUDA" -ForegroundColor Cyan
    Write-Host "======================================" -ForegroundColor Cyan
    Write-Host "Input : $MediaPath"
    Write-Host "Output: $Output"
    Write-Host ""

    # --------------------------------------------------------
    # Execute Whisper
    # --------------------------------------------------------

    & $Python -m whisper `
        "$MediaPath" `
        --model large-v2 `
        --device cuda `
        --output_format srt `
        --output_dir "$OutputDir"

    if ($LASTEXITCODE -ne 0) {
        throw "Whisper transcription failed with exit code: $LASTEXITCODE"
    }

    # --------------------------------------------------------
    # Rename generated subtitle if custom output was given
    # --------------------------------------------------------

    $Generated = Join-Path $OutputDir ($Name + ".srt")

    if (!(Test-Path -LiteralPath $Generated)) {
        throw "Whisper finished but the expected SRT file was not generated: $Generated"
    }

    if ($Generated -ne $Output) {
        Move-Item -LiteralPath $Generated -Destination $Output -Force
    }

    # --------------------------------------------------------
    # Completion
    # --------------------------------------------------------

    Write-Host ""
    Write-Host "======================================" -ForegroundColor Green
    Write-Host " TRANSCRIPTION COMPLETED" -ForegroundColor Green
    Write-Host "======================================" -ForegroundColor Green
    Write-Host "Output: $Output" -ForegroundColor Green

}